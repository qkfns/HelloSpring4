create definer = playground@`%` view 우수고객 as
select `playground`.`sales_customers`.`scustid`   AS `scustid`,
       `playground`.`sales_customers`.`scustname` AS `scustname`,
       `playground`.`sales_customers`.`scustage`  AS `scustage`
from `playground`.`sales_customers`
where `playground`.`sales_customers`.`scustgrd` = 'vip';

