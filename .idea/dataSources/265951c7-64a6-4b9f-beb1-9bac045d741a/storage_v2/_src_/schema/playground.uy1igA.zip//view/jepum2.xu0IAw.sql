create definer = playground@`%` view 제품2 as
select `playground`.`sales_product2`.`prodno`   AS `제품번호`,
       `playground`.`sales_product2`.`stock`    AS `재고량`,
       `playground`.`sales_product2`.`prdmaker` AS `제조업체`
from `playground`.`sales_product2`;

